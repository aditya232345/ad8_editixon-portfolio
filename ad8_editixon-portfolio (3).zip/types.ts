export interface Project {
  id: number;
  title: string;
  category: string;
  description: string;
  details?: string;
  imageUrl: string;
  link?: string;
}

export interface NavItem {
  label: string;
  href: string;
}