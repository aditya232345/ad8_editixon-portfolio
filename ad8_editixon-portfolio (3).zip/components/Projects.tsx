import React, { useRef, useState } from 'react';
import { PROJECTS } from '../constants';
import { motion, useScroll, useTransform, AnimatePresence } from 'framer-motion';
import { ExternalLink, ArrowUpRight, Plus, Minus } from 'lucide-react';
import { Project } from '../types';

interface ProjectCardProps {
  project: Project;
  index: number;
}

const ProjectCard: React.FC<ProjectCardProps> = ({ project, index }) => {
  const ref = useRef<HTMLDivElement>(null);
  const [isExpanded, setIsExpanded] = useState(false);
  
  // Track scroll progress of this specific card
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start end", "end start"]
  });

  // Map scroll progress to vertical movement for parallax
  const y = useTransform(scrollYProgress, [0, 1], ["-10%", "10%"]);

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 50 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-50px" }}
      transition={{ duration: 0.6, delay: index * 0.1 }}
      className="group relative"
    >
      {/* Backlight Glow Effect */}
      <motion.div 
        className="absolute -inset-4 bg-accent/20 dark:bg-accent/10 rounded-3xl blur-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-500 -z-10 pointer-events-none"
        initial={false}
      />

      {/* Interactive Card Container */}
      <motion.div
        whileHover={{ y: -12 }}
        transition={{ type: "spring", stiffness: 400, damping: 20 }}
      >
          {/* Main Clickable Image Area */}
          <a 
            href={project.link || "#"} 
            target="_blank" 
            rel="noopener noreferrer" 
            className="block cursor-pointer"
            onClick={(e) => {
              if (!project.link) e.preventDefault();
            }}
          >
            <div className="aspect-video overflow-hidden border-2 border-transparent group-hover:border-accent transition-colors duration-300 relative bg-gray-200 dark:bg-gray-900 shadow-2xl rounded-lg transform-gpu">
              <div className="absolute inset-0 bg-accent/20 z-10 opacity-0 group-hover:opacity-100 transition-opacity duration-300 mix-blend-overlay pointer-events-none"></div>
              
              {/* Parallax Image */}
              <motion.img 
                src={project.imageUrl} 
                alt={project.title} 
                className="w-full h-[120%] object-cover filter grayscale group-hover:grayscale-0 transition-all duration-500 -mt-[10%]"
                style={{ y }}
                whileHover={{ scale: 1.05 }}
                transition={{ duration: 0.5, ease: "easeOut" }}
              />
              
              {/* Overlay UI */}
              <div className="absolute top-4 right-4 z-20 opacity-0 group-hover:opacity-100 transition-opacity duration-300 translate-x-2 group-hover:translate-x-0">
                  <span
                    className="bg-black text-white p-2 rounded-full block hover:bg-accent transition-colors shadow-lg"
                    aria-label="View Project"
                  >
                      <ExternalLink size={20} />
                  </span>
              </div>
            </div>
          </a>

          <div className="mt-6 flex justify-between items-start">
            <div>
              <a href={project.link || "#"} target="_blank" rel="noopener noreferrer" className="inline-block group/title">
                <h3 className="text-2xl font-bold font-display text-gray-900 dark:text-white group-hover/title:text-accent transition-colors duration-300 flex items-center gap-2">
                  {project.title}
                  <ArrowUpRight className="w-6 h-6 opacity-0 -translate-x-2 group-hover:opacity-100 group-hover:translate-x-0 transition-all duration-300" />
                </h3>
              </a>
              <span className="text-xs font-mono bg-black/5 dark:bg-white/10 text-gray-700 dark:text-gray-300 px-2 py-1 mt-2 inline-block rounded group-hover:bg-accent group-hover:text-white transition-all duration-300 shadow-sm group-hover:shadow-[0_0_10px_rgba(255,0,60,0.5)] transform group-hover:scale-105 group-hover:tracking-wider origin-left cursor-default">
                {project.category}
              </span>
            </div>
            <span 
                className="font-mono text-4xl font-bold text-transparent select-none"
                style={{ WebkitTextStroke: '1px rgba(128, 128, 128, 0.3)' }}
            >
              0{index + 1}
            </span>
          </div>
          
          <div className="mt-4">
            <p className="text-gray-600 dark:text-gray-400 leading-relaxed max-w-md group-hover:text-black dark:group-hover:text-white transition-colors duration-300">
              {project.description}
            </p>

            <AnimatePresence>
              {isExpanded && project.details && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  transition={{ duration: 0.3, ease: "easeInOut" }}
                  className="overflow-hidden"
                >
                  <p className="pt-4 text-sm text-gray-500 dark:text-gray-400 font-mono border-t border-dashed border-gray-300 dark:border-gray-800 mt-4">
                    <span className="text-accent mr-2">&gt;&gt;</span>
                    {project.details}
                  </p>
                </motion.div>
              )}
            </AnimatePresence>

            <motion.button
              onClick={(e) => {
                e.stopPropagation();
                setIsExpanded(!isExpanded);
              }}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="mt-4 text-xs font-mono font-bold text-accent hover:text-black dark:hover:text-white transition-colors uppercase tracking-widest flex items-center gap-2 origin-left"
            >
              [{isExpanded ? " SYSTEM_OFF " : " READ_MORE "}]
              {isExpanded ? <Minus size={12} /> : <Plus size={12} />}
            </motion.button>
          </div>
      </motion.div>
    </motion.div>
  );
};

const Projects: React.FC = () => {
  return (
    <section id="projects" className="py-24 px-6 md:px-20 relative overflow-hidden">
      
      {/* Subtle Animated Background Elements */}
      <div className="absolute inset-0 pointer-events-none select-none">
         <motion.div
            animate={{
                x: [0, 100, 0],
                y: [0, -50, 0],
                scale: [1, 1.2, 1],
                opacity: [0.3, 0.5, 0.3]
            }}
            transition={{
                duration: 15,
                repeat: Infinity,
                ease: "easeInOut"
            }}
            className="absolute top-0 left-0 w-[500px] h-[500px] bg-accent/5 dark:bg-accent/10 rounded-full blur-[100px] mix-blend-multiply dark:mix-blend-screen"
        />
         <motion.div
            animate={{
                x: [0, -70, 0],
                y: [0, 100, 0],
                scale: [1, 1.5, 1],
                opacity: [0.2, 0.4, 0.2]
            }}
            transition={{
                duration: 18,
                repeat: Infinity,
                ease: "easeInOut",
                delay: 2
            }}
            className="absolute bottom-0 right-0 w-[600px] h-[600px] bg-blue-500/5 dark:bg-blue-500/10 rounded-full blur-[120px] mix-blend-multiply dark:mix-blend-screen"
        />
         <motion.div
            animate={{
                x: [0, 50, -50, 0],
                y: [0, 50, 50, 0],
                opacity: [0.1, 0.3, 0.1]
            }}
            transition={{
                duration: 25,
                repeat: Infinity,
                ease: "linear",
            }}
            className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-purple-500/5 dark:bg-purple-500/10 rounded-full blur-[150px] mix-blend-multiply dark:mix-blend-screen"
        />
      </div>

      <div className="max-w-7xl mx-auto relative z-10">
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="mb-16 border-b border-black/10 dark:border-white/20 pb-8 transition-colors duration-500"
        >
          <h2 className="text-4xl md:text-6xl font-black font-display tracking-tight mb-2 text-black dark:text-white">
            MY EGOISTIC WORK
          </h2>
          <p className="font-mono text-accent opacity-80 max-w-xl font-bold">
             // WARNING: VISUAL OVERLOAD IMMINENT. 
             // THESE ARE NOT JUST EDITS; THEY ARE STATEMENTS.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12">
          {PROJECTS.map((project, index) => (
            <ProjectCard key={project.id} project={project} index={index} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Projects;