import React, { useState } from 'react';
import { Mail, Instagram, Send, Check, Loader2 } from 'lucide-react';
import { motion } from 'framer-motion';

const Footer: React.FC = () => {
  const [formState, setFormState] = useState<'idle' | 'sending' | 'success'>('idle');
  
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: ''
  });

  const [errors, setErrors] = useState({
    name: '',
    email: '',
    message: ''
  });

  const validateForm = () => {
    let isValid = true;
    const newErrors = { name: '', email: '', message: '' };

    // Name Validation
    if (!formData.name.trim()) {
      newErrors.name = 'Name is required.';
      isValid = false;
    }

    // Email Validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!formData.email.trim()) {
      newErrors.email = 'Email is required.';
      isValid = false;
    } else if (!emailRegex.test(formData.email)) {
      newErrors.email = 'Please enter a valid email address.';
      isValid = false;
    }

    // Message Validation
    if (!formData.message.trim()) {
      newErrors.message = 'Message cannot be empty.';
      isValid = false;
    }

    setErrors(newErrors);
    return isValid;
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { id, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [id]: value
    }));
    
    // Clear error when user types
    if (errors[id as keyof typeof errors]) {
      setErrors(prev => ({
        ...prev,
        [id]: ''
      }));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    setFormState('sending');
    
    // Simulate API delay
    setTimeout(() => {
      setFormState('success');
      setFormData({ name: '', email: '', message: '' }); // Clear form
      // Reset after 3 seconds
      setTimeout(() => setFormState('idle'), 3000);
    }, 2000);
  };

  return (
    <footer id="contact" className="py-20 border-t border-black/10 dark:border-white/10 bg-gray-50 dark:bg-black/40 backdrop-blur-md transition-colors duration-500">
      <div className="max-w-7xl mx-auto px-6 md:px-20">
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-16">
          
          {/* Left Column: Branding & Info */}
          <div className="flex flex-col justify-between h-full">
            <div>
              <h4 className="font-display font-black text-4xl md:text-5xl tracking-tighter mb-6">
                AD8_<span className="text-accent">EDITIXON</span>
              </h4>
              <p className="font-mono text-sm md:text-base opacity-70 max-w-sm leading-relaxed mb-8">
                Visual engineering for the modern age. Let's create something that breaks the internet.
              </p>
            </div>

            <div className="space-y-8">
              <div className="flex gap-6">
                  <motion.a 
                    href="https://www.instagram.com/ad8_editixon/" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    whileHover={{ scale: 1.1, y: -3 }}
                    whileTap={{ scale: 0.9 }}
                    className="p-3 bg-black/5 dark:bg-white/5 rounded-full hover:bg-accent hover:text-white dark:hover:text-white transition-colors duration-300"
                  >
                      <Instagram size={20} />
                  </motion.a>
                  
                  <motion.a 
                    href="https://discordapp.com/users/1090871868644401254" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    whileHover={{ scale: 1.1, y: -3 }}
                    whileTap={{ scale: 0.9 }}
                    className="p-3 bg-black/5 dark:bg-white/5 rounded-full hover:bg-[#5865F2] hover:text-white transition-colors duration-300 group"
                  >
                      <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg" className="text-gray-600 dark:text-white group-hover:text-white transition-colors">
                        <path d="M18.942 5.556a16.3 16.3 0 0 0-4.126-1.3 0.07 0.07 0 0 0-.07.03 11.95 11.95 0 0 0-.546 1.13 15.88 15.88 0 0 0-4.412 0 11.95 11.95 0 0 0-.546-1.13 0.07 0.07 0 0 0-.07-.03 16.3 16.3 0 0 0-4.126 1.3 0.08 0.08 0 0 0-.04.05C5.074 10.37 6.134 15.05 7.7 17.29a0.08 0.08 0 0 0 .08.03 16.95 16.95 0 0 0 5.09-2.58 0.07 0.07 0 0 0-.04-.12 11.23 11.23 0 0 1-1.83-.88 0.07 0.07 0 0 1-.01-.12c0.12-.09.25-.19.37-.29a0.07 0.07 0 0 1 .07-.01c3.78 1.73 7.89 1.73 11.64 0a0.07 0.07 0 0 1 .07.01 6.8 6.8 0 0 1 .37.29 0.07 0.07 0 0 1-.01.12 11.23 11.23 0 0 1-1.83.88 0.07 0.07 0 0 0-.04.12 16.95 16.95 0 0 0 5.09 2.58 0.08 0.08 0 0 0 .08-.03c1.45-2.09 2.47-6.55 1.76-11.69a0.08 0.08 0 0 0-.04-.05ZM8.678 14.81c-1.07 0-1.94-.98-1.94-2.18s.85-2.18 1.94-2.18c1.09 0 1.96.98 1.96 2.18s-.86 2.18-1.96 2.18Zm6.62 0c-1.07 0-1.94-.98-1.94-2.18s.85-2.18 1.94-2.18c1.09 0 1.96.98 1.96 2.18s-.87 2.18-1.96 2.18Z"/>
                      </svg>
                  </motion.a>
                  
                  <motion.a 
                    href="mailto:adityakmrtody@gmail.com" 
                    whileHover={{ scale: 1.1, y: -3 }}
                    whileTap={{ scale: 0.9 }}
                    className="p-3 bg-black/5 dark:bg-white/5 rounded-full hover:bg-accent hover:text-white dark:hover:text-white transition-colors duration-300"
                  >
                      <Mail size={20} />
                  </motion.a>
              </div>
              
              <p className="text-xs opacity-40 font-mono">
                © {new Date().getFullYear()} AD8_EDITIXON Portfolio. All visuals reserved. <br/>
                Designed & Engineered in India.
              </p>
            </div>
          </div>

          {/* Right Column: Contact Form */}
          <div className="bg-white/50 dark:bg-white/5 p-8 rounded-2xl border border-black/5 dark:border-white/5 shadow-xl backdrop-blur-sm relative overflow-hidden group">
            {/* Decorative gradient blob */}
            <div className="absolute top-0 right-0 w-64 h-64 bg-accent/5 rounded-full blur-[80px] -z-10 group-hover:bg-accent/10 transition-colors duration-500"></div>

            <h5 className="font-display font-bold text-2xl mb-6 flex items-center gap-2">
              <span className="w-2 h-8 bg-accent block"></span>
              INITIATE_CONTACT
            </h5>

            <form className="space-y-4" onSubmit={handleSubmit} noValidate>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label htmlFor="name" className="text-xs font-mono font-bold uppercase tracking-wider opacity-60 ml-1">Name</label>
                  <input 
                    type="text" 
                    id="name"
                    value={formData.name}
                    onChange={handleChange}
                    placeholder="ENTER_NAME" 
                    className={`w-full bg-black/5 dark:bg-black/40 border ${errors.name ? 'border-red-500' : 'border-black/10 dark:border-white/10'} rounded-lg p-3 text-sm focus:outline-none focus:border-accent focus:ring-1 focus:ring-accent transition-all font-mono placeholder:opacity-30`}
                  />
                  {errors.name && <p className="text-[10px] text-red-500 font-mono ml-1">{errors.name}</p>}
                </div>
                <div className="space-y-1">
                  <label htmlFor="email" className="text-xs font-mono font-bold uppercase tracking-wider opacity-60 ml-1">Email</label>
                  <input 
                    type="email" 
                    id="email"
                    value={formData.email}
                    onChange={handleChange}
                    placeholder="ENTER_EMAIL" 
                    className={`w-full bg-black/5 dark:bg-black/40 border ${errors.email ? 'border-red-500' : 'border-black/10 dark:border-white/10'} rounded-lg p-3 text-sm focus:outline-none focus:border-accent focus:ring-1 focus:ring-accent transition-all font-mono placeholder:opacity-30`}
                  />
                  {errors.email && <p className="text-[10px] text-red-500 font-mono ml-1">{errors.email}</p>}
                </div>
              </div>

              <div className="space-y-1">
                <label htmlFor="message" className="text-xs font-mono font-bold uppercase tracking-wider opacity-60 ml-1">Brief</label>
                <textarea 
                  id="message"
                  value={formData.message}
                  onChange={handleChange}
                  rows={4} 
                  placeholder="DESCRIBE_PROJECT_DETAILS..." 
                  className={`w-full bg-black/5 dark:bg-black/40 border ${errors.message ? 'border-red-500' : 'border-black/10 dark:border-white/10'} rounded-lg p-3 text-sm focus:outline-none focus:border-accent focus:ring-1 focus:ring-accent transition-all font-mono placeholder:opacity-30 resize-none`}
                ></textarea>
                {errors.message && <p className="text-[10px] text-red-500 font-mono ml-1">{errors.message}</p>}
              </div>

              <button 
                type="submit" 
                disabled={formState !== 'idle'}
                className={`w-full py-4 rounded-lg font-display font-bold text-lg transition-all duration-300 flex items-center justify-center gap-2 group/btn relative overflow-hidden ${
                  formState === 'success' 
                    ? 'bg-green-500 text-white' 
                    : 'bg-black dark:bg-white text-white dark:text-black hover:bg-accent dark:hover:bg-accent hover:text-white dark:hover:text-white'
                }`}
              >
                {formState === 'idle' && (
                  <>
                    <span className="relative z-10 flex items-center gap-2">
                      TRANSMIT DATA <Send size={18} className="group-hover/btn:translate-x-1 transition-transform" />
                    </span>
                    <div className="absolute inset-0 bg-accent translate-y-full group-hover/btn:translate-y-0 transition-transform duration-300 ease-in-out"></div>
                  </>
                )}
                
                {formState === 'sending' && (
                  <span className="relative z-10 flex items-center gap-2">
                    TRANSMITTING <Loader2 size={18} className="animate-spin" />
                  </span>
                )}
                
                {formState === 'success' && (
                  <span className="relative z-10 flex items-center gap-2">
                    DATA SENT <Check size={18} />
                  </span>
                )}
              </button>
            </form>
          </div>

        </div>
      </div>
    </footer>
  );
};

export default Footer;