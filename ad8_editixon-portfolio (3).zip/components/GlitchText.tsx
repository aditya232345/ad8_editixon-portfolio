import React from 'react';

interface GlitchTextProps {
  text: string;
  className?: string;
  large?: boolean;
}

const GlitchText: React.FC<GlitchTextProps> = ({ text, className = "", large = false }) => {
  return (
    <div className={`relative inline-block group ${className}`}>
      <span className="relative z-10">{text}</span>
      <span 
        className={`absolute top-0 left-0 -z-10 opacity-0 group-hover:opacity-100 group-hover:animate-glitch text-accent w-full ${large ? 'translate-x-[2px]' : ''}`}
        aria-hidden="true"
      >
        {text}
      </span>
      <span 
        className={`absolute top-0 left-0 -z-10 opacity-0 group-hover:opacity-100 group-hover:animate-glitch text-blue-500 w-full animation-delay-200 ${large ? '-translate-x-[2px]' : ''}`}
        aria-hidden="true"
        style={{ animationDirection: 'reverse' }}
      >
        {text}
      </span>
    </div>
  );
};

export default GlitchText;