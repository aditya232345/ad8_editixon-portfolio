import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';

const Loader: React.FC = () => {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(timer);
          return 100;
        }
        // Random increment for a more "realistic" data loading feel
        return Math.min(prev + Math.floor(Math.random() * 10) + 1, 100);
      });
    }, 150);

    return () => clearInterval(timer);
  }, []);

  return (
    <motion.div
      initial={{ opacity: 1 }}
      exit={{ 
        opacity: 0,
        y: -50,
        transition: { duration: 0.8, ease: "easeInOut" } 
      }}
      className="fixed inset-0 z-[100] bg-black flex flex-col items-center justify-center text-white"
    >
      <div className="w-64 md:w-96 relative">
        {/* Glitchy Title */}
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5 }}
          className="flex justify-between items-end mb-2"
        >
          <span className="font-display font-bold text-2xl tracking-tighter">
            AD8_EDITIXON
          </span>
          <span className="font-mono text-accent text-xl font-bold">
            {progress}%
          </span>
        </motion.div>

        {/* Progress Bar Container */}
        <div className="h-1 w-full bg-gray-800 overflow-hidden relative">
          {/* Active Bar */}
          <motion.div
            className="h-full bg-accent shadow-[0_0_15px_rgba(255,0,60,0.8)]"
            initial={{ width: "0%" }}
            animate={{ width: `${progress}%` }}
            transition={{ ease: "linear", duration: 0.1 }} // Quick snapping updates
          />
        </div>

        {/* System Messages */}
        <div className="mt-2 font-mono text-[10px] text-gray-500 flex justify-between uppercase">
          <span>
            {progress < 30 ? "Initializing Core..." : 
             progress < 60 ? "Loading Assets..." : 
             progress < 90 ? "Calibrating Visuals..." : 
             "System Ready"}
          </span>
          <span>v2.0.4</span>
        </div>
      </div>
      
      {/* Decorative blurred glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-accent/5 rounded-full blur-[100px] -z-10 pointer-events-none"></div>
    </motion.div>
  );
};

export default Loader;