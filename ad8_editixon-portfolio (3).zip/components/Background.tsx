import React, { useEffect, useRef } from 'react';

const Background: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let width = window.innerWidth;
    let height = window.innerHeight;
    canvas.width = width;
    canvas.height = height;

    // --- Mouse State ---
    let mouseX = 0;
    let mouseY = 0;
    
    // Interpolated values for smooth animation
    let currentRotationX = 0;
    let currentRotationY = 0;
    let currentOffsetX = 0;
    let currentOffsetY = 0;

    const handleMouseMove = (e: MouseEvent) => {
      // Calculate from center
      mouseX = e.clientX - width / 2;
      mouseY = e.clientY - height / 2;
    };
    window.addEventListener('mousemove', handleMouseMove);

    // --- 3D Shape Data (Icosahedron) ---
    const phi = (1 + Math.sqrt(5)) / 2;
    const baseSize = 180;
    
    const baseVertices = [
        [-1,  phi, 0], [ 1,  phi, 0], [-1, -phi, 0], [ 1, -phi, 0],
        [ 0, -1,  phi], [ 0,  1,  phi], [ 0, -1, -phi], [ 0,  1, -phi],
        [ phi, 0, -1], [ phi, 0,  1], [-phi, 0, -1], [-phi, 0,  1]
    ].map(v => ({ x: v[0] * baseSize, y: v[1] * baseSize, z: v[2] * baseSize }));

    const edges = [
        [0, 1], [0, 5], [0, 7], [0, 10], [0, 11],
        [1, 5], [1, 7], [1, 8], [1, 9],
        [2, 3], [2, 4], [2, 6], [2, 10], [2, 11],
        [3, 4], [3, 6], [3, 8], [3, 9],
        [4, 5], [4, 9], [4, 11], [5, 9],
        [6, 7], [6, 8], [6, 10], [7, 8],
        [8, 9], [10, 11]
    ];

    // --- GFX Particle Class (New) ---
    class GFXParticle {
      x: number;
      y: number;
      type: number; // 0: crosshair, 1: corner, 2: text, 3: ring
      life: number;
      maxLife: number;
      size: number;
      text: string;
      velX: number;
      velY: number;
      colorVariant: number; // 0: Base, 1: Accent Red, 2: Accent Cyan/Blue

      constructor(w: number, h: number) {
        this.x = Math.random() * w;
        this.y = Math.random() * h;
        this.type = Math.floor(Math.random() * 4);
        this.maxLife = 100 + Math.random() * 150;
        this.life = 0;
        this.size = 10 + Math.random() * 10;
        // Random hex string
        this.text = Math.random().toString(16).substring(2, 6).toUpperCase();
        
        // Very slow drift
        this.velX = (Math.random() - 0.5) * 0.5;
        this.velY = (Math.random() - 0.5) * 0.5;

        // Assign random color variant
        this.colorVariant = Math.floor(Math.random() * 3);
      }

      update() {
        this.life++;
        this.x += this.velX;
        this.y += this.velY;
      }

      isDead() {
        return this.life >= this.maxLife;
      }

      draw(ctx: CanvasRenderingContext2D, isDark: boolean) {
        const progress = this.life / this.maxLife;
        // Fade in and out using sine wave
        const alpha = Math.sin(progress * Math.PI) * (isDark ? 0.5 : 0.3);
        
        let r, g, b;
        
        if (isDark) {
            if (this.colorVariant === 0) { // White (Base)
                r = 255; g = 255; b = 255; 
            } else if (this.colorVariant === 1) { // Accent Red
                r = 255; g = 0; b = 60;
            } else { // Cyan
                r = 0; g = 240; b = 255;
            }
        } else {
            if (this.colorVariant === 0) { // Dark Grey (Base)
                r = 40; g = 40; b = 40; 
            } else if (this.colorVariant === 1) { // Deep Red
                r = 200; g = 20; b = 60;
            } else { // Deep Blue
                r = 0; g = 100; b = 180;
            }
        }

        const color = `rgba(${r}, ${g}, ${b}, ${alpha})`;
        ctx.strokeStyle = color;
        ctx.fillStyle = color;
        ctx.lineWidth = 1;

        if (this.type === 0) { 
            // Crosshair
            const s = this.size;
            ctx.beginPath();
            ctx.moveTo(this.x - s, this.y);
            ctx.lineTo(this.x + s, this.y);
            ctx.moveTo(this.x, this.y - s);
            ctx.lineTo(this.x, this.y + s);
            ctx.stroke();
            
            // Tiny label
            ctx.font = '8px "Fira Code", monospace';
            ctx.fillText(`T-${this.text}`, this.x + s + 2, this.y + s + 2);

        } else if (this.type === 1) { 
            // Corner Bracket
            const s = this.size;
            ctx.beginPath();
            ctx.moveTo(this.x, this.y - s);
            ctx.lineTo(this.x, this.y);
            ctx.lineTo(this.x + s, this.y);
            ctx.stroke();

        } else if (this.type === 2) { 
            // Floating Data
            ctx.font = '10px "Fira Code", monospace';
            ctx.fillText(`0x${this.text} // EDIT`, this.x, this.y);

        } else if (this.type === 3) { 
            // Dotted Circle
            const s = this.size * 1.5;
            ctx.beginPath();
            ctx.setLineDash([2, 4]);
            ctx.arc(this.x, this.y, s, 0, Math.PI * 2);
            ctx.stroke();
            ctx.setLineDash([]);
        }
      }
    }

    // --- Standard Particle Class ---
    class Particle {
      x: number;
      y: number;
      z: number;
      vx: number;
      vy: number;
      vz: number;
      size: number;
      phase: number;
      type: 'standard' | 'slow';

      constructor(type: 'standard' | 'slow' = 'standard') {
        this.type = type;
        this.x = Math.random() * width - width / 2;
        this.y = Math.random() * height - height / 2;
        this.z = Math.random() * width; 
        
        if (type === 'slow') {
           this.vx = (Math.random() - 0.5) * 0.2; 
           this.vy = (Math.random() - 0.5) * 0.2; 
           this.vz = Math.random() * 0.2 + 0.1;     
           this.size = Math.random() * 3 + 4;
        } else {
           this.vx = (Math.random() - 0.5) * 2; 
           this.vy = (Math.random() - 0.5) * 2; 
           this.vz = Math.random() * 2 + 1;     
           this.size = Math.random() * 2 + 1;
        }
        
        this.phase = Math.random() * Math.PI * 2;
      }

      update(time: number) {
        this.z -= this.vz;
        
        if (this.z <= 0) {
          this.z = width;
          this.x = Math.random() * width - width / 2;
          this.y = Math.random() * height - height / 2;
        }

        if (this.type === 'slow') {
             this.x += this.vx + Math.sin(time * 0.0002 + this.phase) * 0.2;
             this.y += this.vy + Math.cos(time * 0.0003 + this.phase) * 0.2;
        } else {
             this.x += this.vx + Math.sin(time * 0.002 + this.phase) * 0.8;
             this.y += this.vy + Math.cos(time * 0.003 + this.phase) * 0.8;
        }
      }

      draw(ctx: CanvasRenderingContext2D, centerX: number, centerY: number, isDark: boolean, time: number) {
        const fov = 300;
        const scale = fov / (fov + this.z);
        const x2d = this.x * scale + centerX;
        const y2d = this.y * scale + centerY;
        const s2d = this.size * scale;

        const alpha = Math.max(0, 1 - this.z / width);
        let r, g, b;

        if (this.type === 'slow') {
             if (isDark) {
                r = 255; g = 215; b = 0; // Gold
             } else {
                r = 0; g = 150; b = 150; // Teal
             }
        } else {
            if (isDark) {
                r = Math.floor(Math.sin(time * 0.001 + this.phase) * 50);
                g = Math.floor(Math.cos(time * 0.001) * 50);
                b = 255;
            } else {
                const pulse = Math.sin(time * 0.002 + this.phase);
                if (pulse > 0.8) {
                    r = 255; g = 0; b = 60;
                } else {
                    r = 20; g = 20; b = 20;
                }
            }
        }

        ctx.fillStyle = `rgba(${r}, ${g}, ${b}, ${alpha})`;
        
        if (this.type === 'slow') {
            // Draw square
            ctx.fillRect(x2d - s2d/2, y2d - s2d/2, s2d, s2d);
        } else {
            // Draw circle
            ctx.beginPath();
            ctx.arc(x2d, y2d, s2d, 0, Math.PI * 2);
            ctx.fill();
        }
      }
    }

    const particles: Particle[] = [];
    const gfxParticles: GFXParticle[] = [];

    // Initialize Particles
    for (let i = 0; i < 70; i++) particles.push(new Particle('standard'));
    for (let i = 0; i < 15; i++) particles.push(new Particle('slow'));

    let time = 0;
    const animate = () => {
      time += 16;
      const isDark = document.documentElement.classList.contains('dark');
      
      ctx.clearRect(0, 0, width, height);
      const centerX = width / 2;
      const centerY = height / 2;

      // 1. Draw Standard Particles
      particles.forEach(p => {
        p.update(time);
        p.draw(ctx, centerX, centerY, isDark, time);
      });

      // 2. Draw Connections (Standard Only)
      const fov = 300;
      particles.forEach((p1, i) => {
         if (p1.type !== 'standard') return;
         
         const scale1 = fov / (fov + p1.z);
         const x1 = p1.x * scale1 + centerX;
         const y1 = p1.y * scale1 + centerY;
         const alpha1 = Math.max(0, 1 - p1.z / width);

         for (let j = i + 1; j < particles.length; j++) {
            const p2 = particles[j];
            if (p2.type !== 'standard') continue;

            const dist = Math.hypot(p1.x - p2.x, p1.y - p2.y, p1.z - p2.z);
            if (dist < 200) {
                 const scale2 = fov / (fov + p2.z);
                 const x2 = p2.x * scale2 + centerX;
                 const y2 = p2.y * scale2 + centerY;
                 
                 let r, g, b;
                 if (isDark) {
                     r = Math.floor(Math.sin(time * 0.001) * 50); 
                     g = Math.floor(Math.cos(time * 0.001) * 50);
                     b = 255;
                 } else {
                     r = 20; g = 20; b = 20;
                 }

                 ctx.strokeStyle = `rgba(${r}, ${g}, ${b}, ${alpha1 * 0.15})`;
                 ctx.lineWidth = 0.5;
                 ctx.beginPath();
                 ctx.moveTo(x1, y1);
                 ctx.lineTo(x2, y2);
                 ctx.stroke();
            }
         }
      });

      // 3. Draw GFX Overlay (New Layer)
      // Randomly spawn new GFX particles
      if (gfxParticles.length < 15 && Math.random() < 0.05) {
          gfxParticles.push(new GFXParticle(width, height));
      }

      // Update and draw GFX
      for (let i = gfxParticles.length - 1; i >= 0; i--) {
          const p = gfxParticles[i];
          p.update();
          p.draw(ctx, isDark);
          if (p.isDead()) {
              gfxParticles.splice(i, 1);
          }
      }

      // 4. Draw Rotating 3D Object (Icosahedron)
      // Smoothly interpolate rotation based on mouse position
      // Mouse Y affects Rotation X, Mouse X affects Rotation Y
      const targetRotationX = mouseY * 0.008; // Increased sensitivity further for responsiveness
      const targetRotationY = mouseX * 0.008; // Increased sensitivity further for responsiveness
      
      // Update position targets (parallax effect)
      const targetOffsetX = mouseX * 0.4; // Stronger parallax based on mouse
      const targetOffsetY = mouseY * 0.4; // Stronger parallax based on mouse

      // Smooth interpolation (Lerp) - increased speed for snappier response
      currentRotationX += (targetRotationX - currentRotationX) * 0.1;
      currentRotationY += (targetRotationY - currentRotationY) * 0.1;
      
      currentOffsetX += (targetOffsetX - currentOffsetX) * 0.1;
      currentOffsetY += (targetOffsetY - currentOffsetY) * 0.1;

      const baseAngleX = time * 0.0002;
      const baseAngleY = time * 0.0003;
      
      const angleX = baseAngleX + currentRotationX;
      const angleY = baseAngleY + currentRotationY;

      // Add a slight pulse to the object
      const pulseScale = 1 + Math.sin(time * 0.002) * 0.1; 
      
      const rotated = baseVertices.map(v => {
          // Scale Pulse
          let x = v.x * pulseScale;
          let y = v.y * pulseScale;
          let z = v.z * pulseScale;

          // Rotate Y
          let x2 = x * Math.cos(angleY) - z * Math.sin(angleY);
          let z2 = x * Math.sin(angleY) + z * Math.cos(angleY);
          
          // Rotate X
          let y2 = y * Math.cos(angleX) - z2 * Math.sin(angleX);
          z2 = y * Math.sin(angleX) + z2 * Math.cos(angleX);

          // Apply Mouse Parallax Position Offset
          x2 += currentOffsetX;
          y2 += currentOffsetY;

          return { x: x2, y: y2, z: z2 + 1200 }; // Push back in scene
      });

      const objFov = 600;
      ctx.lineWidth = 1;
      
      edges.forEach(edge => {
          const v1 = rotated[edge[0]];
          const v2 = rotated[edge[1]];
          
          const scale1 = objFov / v1.z;
          const scale2 = objFov / v2.z;
          
          const x1 = v1.x * scale1 + centerX;
          const y1 = v1.y * scale1 + centerY;
          const x2 = v2.x * scale2 + centerX;
          const y2 = v2.y * scale2 + centerY;

          if (isDark) {
              ctx.strokeStyle = `rgba(255, 0, 60, 0.25)`; // Red-ish tint in dark mode
          } else {
              ctx.strokeStyle = `rgba(0, 0, 0, 0.1)`;
          }

          ctx.beginPath();
          ctx.moveTo(x1, y1);
          ctx.lineTo(x2, y2);
          ctx.stroke();
      });

      // Draw Vertices for Object
      rotated.forEach(v => {
          const scale = objFov / v.z;
          const x = v.x * scale + centerX;
          const y = v.y * scale + centerY;
          
           if (isDark) {
              ctx.fillStyle = `rgba(255, 255, 255, 0.5)`; 
          } else {
              ctx.fillStyle = `rgba(255, 0, 60, 0.5)`;
          }
          
          ctx.beginPath();
          ctx.arc(x, y, 2.5, 0, Math.PI*2);
          ctx.fill();
      });

      requestAnimationFrame(animate);
    };

    const animId = requestAnimationFrame(animate);

    const handleResize = () => {
      width = window.innerWidth;
      height = window.innerHeight;
      canvas.width = width;
      canvas.height = height;
    };

    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('mousemove', handleMouseMove);
      cancelAnimationFrame(animId);
    };
  }, []);

  return (
    <canvas 
      ref={canvasRef} 
      className="fixed top-0 left-0 w-full h-full -z-10 pointer-events-none opacity-100 transition-opacity duration-500"
    />
  );
};

export default Background;