import React from 'react';

interface CyberTextProps {
  text: string;
  className?: string;
  glitchColor1?: string;
  glitchColor2?: string;
  alwaysVisible?: boolean;
  bevel?: boolean;
}

const CyberText: React.FC<CyberTextProps> = ({ 
  text, 
  className = "",
  glitchColor1 = "text-accent",
  glitchColor2 = "text-blue-500",
  alwaysVisible = false,
  bevel = false
}) => {
  // If alwaysVisible is true, we remove the 'group-hover:' prefix so classes apply immediately.
  const hoverPrefix = alwaysVisible ? "" : "group-hover:";
  
  // When always visible, we might want slightly reduced opacity to ensure readability, 
  // or full opacity if the effect relies on clip-paths (which it does).
  // Using 100% opacity for the slices ensures they look crisp.
  const opacityClass = alwaysVisible ? "opacity-100" : "opacity-0 group-hover:opacity-100";

  // Smooth bevel effect using text-shadow: bottom-right shadow + top-left highlight
  const bevelStyle = bevel ? {
    textShadow: '3px 3px 6px rgba(0,0,0,0.5), -1px -1px 2px rgba(255,255,255,0.3)'
  } : {};

  return (
    <div className={`relative inline-block group ${className}`}>
      {/* Base Text */}
      <span 
        className="relative z-10 block"
        style={bevelStyle}
      >
        {text}
      </span>
      
      {/* Glitch Layer 1 - Slices top/bottom periodically */}
      <span 
        className={`absolute inset-0 z-0 ${glitchColor1} ${opacityClass} ${hoverPrefix}animate-glitch-slice-1 pointer-events-none`}
        aria-hidden="true"
        style={bevelStyle}
      >
        {text}
      </span>
      
      {/* Glitch Layer 2 - Slices differently */}
      <span 
        className={`absolute inset-0 z-0 ${glitchColor2} ${opacityClass} ${hoverPrefix}animate-glitch-slice-2 pointer-events-none`}
        aria-hidden="true"
        style={bevelStyle}
      >
        {text}
      </span>
      
      {/* Persistent neon glow */}
      <div className={`absolute inset-0 blur-xl bg-accent/20 ${alwaysVisible ? 'opacity-100' : 'opacity-0 group-hover:opacity-100'} transition-opacity duration-300 -z-10`}></div>
    </div>
  );
};

export default CyberText;