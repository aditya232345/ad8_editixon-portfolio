
import React from 'react';
import { motion } from 'framer-motion';
import CyberText from './CyberText';
import { ChevronDown, Globe, Laptop, User, Cpu, Zap, Activity } from 'lucide-react';

const Hero: React.FC = () => {
  const handleScrollDown = (e: React.MouseEvent<HTMLAnchorElement>) => {
    e.preventDefault();
    document.getElementById('projects')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section id="home" className="min-h-screen flex flex-col justify-center px-6 md:px-20 relative pt-20 overflow-hidden">
      
      {/* Decorative blurred glow behind text - Changes based on theme */}
      <div className="absolute top-1/2 left-1/4 w-64 h-64 bg-accent/10 dark:bg-accent/20 rounded-full blur-[100px] -z-10 mix-blend-multiply dark:mix-blend-screen animate-pulse"></div>

      {/* Main Title Area */}
      <div className="max-w-6xl z-10 relative">
        <motion.p 
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="text-accent font-mono mb-4 tracking-[0.2em] text-xs md:text-sm uppercase font-bold"
        >
          // SYSTEM: ONLINE // WELCOME USER
        </motion.p>
        
        <motion.h1 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="text-5xl md:text-8xl lg:text-9xl font-black font-display tracking-tighter leading-[0.9] mb-8"
        >
          <div className="flex flex-col md:block">
            {/* First Line */}
            <span className="inline-block text-black dark:text-white transition-colors duration-500">
               <CyberText 
                 text="AD8_" 
                 glitchColor1="text-red-600 dark:text-purple-500" 
                 glitchColor2="text-black dark:text-white"
                 alwaysVisible={true}
                 bevel={true}
               />
            </span>
            
            {/* Second Line - Main Name with heavy effect */}
            <span className="md:ml-4 relative inline-block text-accent">
                {/* A subtle strobe light effect behind the main text (Only dark mode) */}
                <span className="absolute -inset-2 blur-2xl bg-accent/10 opacity-0 dark:opacity-50 animate-pulse hidden dark:block"></span>
                <CyberText 
                  text="EDITIXON" 
                  className="tracking-tighter"
                  glitchColor1="text-black dark:text-white"
                  glitchColor2="text-red-500 dark:text-cyan-400"
                  alwaysVisible={true}
                  bevel={true}
                />
            </span>
          </div>
        </motion.h1>

        <motion.div 
          initial={{ width: 0 }}
          animate={{ width: 100 }}
          transition={{ duration: 0.8, delay: 1 }}
          className="h-1 bg-accent mb-8 shadow-[0_0_10px_rgba(255,0,60,0.5)]"
        />
      </div>

      {/* Intro / Bio Card */}
      <motion.div 
        id="about"
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, delay: 0.8 }}
        className="backdrop-blur-md border-l-2 border-accent bg-white/10 dark:bg-black/40 p-6 md:p-10 max-w-5xl shadow-2xl relative overflow-hidden group transition-colors duration-500"
      >
        <div className="flex flex-col-reverse md:flex-row gap-12 items-center md:items-start relative z-10">
          
          {/* Left Side: Text Content */}
          <div className="flex-1">
            <h2 className="text-2xl font-bold mb-6 font-display flex items-center gap-3 text-black dark:text-white">
              <span className="w-3 h-3 bg-accent rounded-full animate-pulse"></span>
              IDENTITY
            </h2>
            
            <div className="space-y-6 text-lg md:text-xl font-light leading-relaxed text-gray-800 dark:text-gray-300">
              <p>
                My name is <span className="font-bold text-black dark:text-white drop-shadow-sm">Aditya</span>.
              </p>
              <p>
                I am a <span className="font-mono text-accent font-semibold">16-year-old</span> advanced editor from <span className="font-bold text-black dark:text-white">India</span>.
                My workspace is the timeline, and my medium is time itself. I craft visuals that don't just move—they <span className="italic font-medium text-black dark:text-white">resonate</span>.
              </p>
              <p className="text-sm md:text-base text-gray-600 dark:text-gray-500 mt-4 border-t border-black/10 dark:border-white/10 pt-4 flex items-center gap-2">
                <span className="inline-block w-2 h-2 bg-green-500 rounded-full animate-pulse"></span> 
                Status: Available for high-end commissions.
              </p>
            </div>

            <div className="flex flex-wrap gap-4 mt-8">
                <div className="bg-black/5 dark:bg-white/5 border border-black/10 dark:border-white/10 px-4 py-2 rounded-full flex items-center gap-2 text-xs font-mono text-gray-600 dark:text-gray-400 hover:border-accent/50 transition-colors cursor-default">
                    <Globe size={14} className="text-accent" /> INDIA
                </div>
                <div className="bg-black/5 dark:bg-white/5 border border-black/10 dark:border-white/10 px-4 py-2 rounded-full flex items-center gap-2 text-xs font-mono text-gray-600 dark:text-gray-400 hover:border-accent/50 transition-colors cursor-default">
                    <User size={14} className="text-accent" /> 16 Y/O
                </div>
                <div className="bg-black/5 dark:bg-white/5 border border-black/10 dark:border-white/10 px-4 py-2 rounded-full flex items-center gap-2 text-xs font-mono text-gray-600 dark:text-gray-400 hover:border-accent/50 transition-colors cursor-default">
                    <Laptop size={14} className="text-accent" /> ADVANCED EDITOR
                </div>
            </div>
          </div>

          {/* Right Side: Image & Stats */}
          <div className="relative shrink-0 w-full md:w-auto flex flex-col items-center md:items-end gap-6">
             
             {/* Profile Image */}
             <div className="w-48 h-48 md:w-72 md:h-72 relative rounded-lg overflow-hidden border-2 border-white/10 shadow-[0_0_30px_rgba(0,0,0,0.5)] group-hover:border-accent/60 transition-all duration-500">
                {/* Glowing Aura */}
                <div className="absolute inset-0 bg-accent/20 animate-pulse z-0 hidden group-hover:block transition-all"></div>
                
                {/* Profile Image */}
                <img 
                   src="https://conventional-apricot-ftihadrm3c-l5662p68f7.edgeone.dev/Nagi%20icon.jpg"
                   alt="Aditya Identity" 
                   className="relative z-10 w-full h-full object-cover filter grayscale contrast-125 brightness-90 group-hover:grayscale-0 group-hover:brightness-100 transition-all duration-700 transform group-hover:scale-110"
                />
                
                {/* Scanline Overlay */}
                <div className="absolute inset-0 bg-[linear-gradient(transparent_50%,rgba(0,0,0,0.8)_50%)] bg-[length:100%_4px] pointer-events-none z-20 opacity-40 group-hover:opacity-20 transition-opacity"></div>
             </div>

             {/* Decorative Tech Corners for Image */}
             <div className="absolute -top-3 right-1/2 md:-right-3 md:translate-x-0 translate-x-1/2 w-6 h-6 border-t-2 border-r-2 border-accent opacity-0 group-hover:opacity-100 transition-all duration-500 delay-100"></div>
             <div className="absolute -bottom-3 right-1/2 md:-left-3 md:translate-x-0 translate-x-1/2 w-6 h-6 border-b-2 border-l-2 border-accent opacity-0 group-hover:opacity-100 transition-all duration-500 delay-100"></div>

             {/* Stats / Tools Panel - Fills the empty space */}
             <div className="w-full md:w-72 grid grid-cols-2 gap-2">
                 <div className="bg-black/5 dark:bg-white/5 p-2 rounded border border-transparent hover:border-accent/30 transition-colors">
                     <div className="flex items-center gap-2 mb-1">
                        <Cpu size={12} className="text-accent" />
                        <span className="text-[10px] font-mono font-bold text-gray-500">SOFTWARE</span>
                     </div>
                     <div className="flex gap-1 flex-wrap">
                        <span className="text-[9px] bg-black/10 dark:bg-white/10 px-1 rounded text-gray-600 dark:text-gray-300">AM</span>
                        <span className="text-[9px] bg-black/10 dark:bg-white/10 px-1 rounded text-gray-600 dark:text-gray-300">CapCut</span>
                        <span className="text-[9px] bg-black/10 dark:bg-white/10 px-1 rounded text-gray-600 dark:text-gray-300">Alight Motion</span>
                     </div>
                 </div>
                 <div className="bg-black/5 dark:bg-white/5 p-2 rounded border border-transparent hover:border-accent/30 transition-colors">
                     <div className="flex items-center gap-2 mb-1">
                        <Activity size={12} className="text-accent" />
                        <span className="text-[10px] font-mono font-bold text-gray-500">UPTIME</span>
                     </div>
                     <div className="text-xs font-mono text-gray-700 dark:text-gray-200">
                        99.9% SYNC
                     </div>
                 </div>
                 <div className="col-span-2 bg-black/5 dark:bg-white/5 p-2 rounded border border-transparent hover:border-accent/30 transition-colors flex items-center justify-between">
                     <div className="flex items-center gap-2">
                        <Zap size={12} className="text-yellow-500" />
                        <span className="text-[10px] font-mono font-bold text-gray-500">ENERGY LVL</span>
                     </div>
                     <div className="w-20 h-1 bg-gray-300 dark:bg-gray-700 rounded-full overflow-hidden">
                        <div className="h-full bg-accent w-[85%]"></div>
                     </div>
                 </div>
             </div>

          </div>

        </div>
      </motion.div>

      {/* Scroll Indicator */}
      <motion.a
        href="#projects"
        onClick={handleScrollDown}
        animate={{ y: [0, 10, 0], opacity: [0.3, 1, 0.3] }}
        transition={{ repeat: Infinity, duration: 2 }}
        className="absolute bottom-10 right-10 flex flex-col items-center gap-2 text-accent cursor-pointer z-20 hover:text-accent/80 transition-colors"
      >
        <span className="text-[10px] font-mono tracking-widest writing-vertical-rl transform rotate-180">SCROLL_DOWN</span>
        <ChevronDown />
      </motion.a>
    </section>
  );
};

export default Hero;
