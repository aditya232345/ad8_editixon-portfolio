import React from 'react';
import { motion } from 'framer-motion';

const Watermark: React.FC = () => {
  return (
    <motion.div 
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 1.5, delay: 2.5, ease: "easeOut" }}
      className="fixed bottom-10 left-0 z-50 transform -rotate-90 origin-bottom-left mix-blend-difference cursor-pointer group"
      onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
    >
      <motion.div 
        animate={{ 
          opacity: [0.7, 1, 0.7],
          scale: [1, 1.02, 1]
        }}
        transition={{ 
          duration: 4, 
          repeat: Infinity, 
          ease: "easeInOut" 
        }}
        whileHover={{ opacity: 1, x: 10, scale: 1.1, transition: { duration: 0.3 } }}
        className="flex items-center gap-4 pl-4"
      >
        <div className="h-[1px] w-12 bg-white opacity-50 transition-all duration-300 group-hover:w-20 group-hover:opacity-100 group-hover:shadow-[0_0_8px_rgba(255,255,255,0.8)]"></div>
        <motion.span 
          className="font-mono text-xs tracking-[0.3em] font-bold text-white uppercase transition-all duration-300 group-hover:drop-shadow-[0_0_5px_rgba(255,255,255,0.6)]"
          whileHover={{ textShadow: "0px 0px 8px rgb(255, 255, 255)" }}
          transition={{ duration: 0.3 }}
        >
          EDITIXON WORKS
        </motion.span>
      </motion.div>
    </motion.div>
  );
};

export default Watermark;