import React, { useState, useEffect } from 'react';
import { AnimatePresence } from 'framer-motion';
import Background from './components/Background';
import Navigation from './components/Navigation';
import Hero from './components/Hero';
import Projects from './components/Projects';
import Watermark from './components/Watermark';
import Footer from './components/Footer';
import Loader from './components/Loader';

const App: React.FC = () => {
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Total loading time simulates initialization (approx 2.5s)
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 2500);

    return () => clearTimeout(timer);
  }, []);

  return (
    <main className="relative w-full min-h-screen">
      <AnimatePresence mode="wait">
        {isLoading && <Loader />}
      </AnimatePresence>

      <Background />
      <Navigation />
      <Watermark />
      
      <Hero />
      <Projects />
      <Footer />
    </main>
  );
};

export default App;