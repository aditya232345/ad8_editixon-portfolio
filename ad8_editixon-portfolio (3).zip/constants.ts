import { Project, NavItem } from './types';

export const NAV_ITEMS: NavItem[] = [
  { label: 'HOME', href: '#home' },
  { label: 'WHO I AM', href: '#about' },
  { label: 'EGOISTIC WORK', href: '#projects' },
  { label: 'CONTACT', href: '#contact' },
];

export const PROJECTS: Project[] = [
  {
    id: 1,
    title: "NEON GENESIS",
    category: "COMPOSITING",
    description: "A high-octane cyberpunk sequence pushing the boundaries of color grading and motion tracking.",
    details: "Built using After Effects and Blender, this project utilizes advanced rotoscoping techniques and custom Python scripts for procedural city generation. The color grading process involved a custom ACES pipeline to ensure maximum dynamic range in the neon-lit environments.",
    imageUrl: "https://picsum.photos/800/600?random=1",
    link: "https://dribbble.com/tags/cyberpunk"
  },
  {
    id: 2,
    title: "VOID WALKER",
    category: "VISUAL ANIMATION",
    description: "Abstract character study involving complex particle simulations and fluid dynamics.",
    details: "A deep dive into Houdini's FLIP fluid solvers and Vellum cloth simulations. The character rig was custom-built to interact with millions of particles in real-time, rendered in Redshift for photorealistic light scattering and refraction.",
    imageUrl: "https://picsum.photos/800/600?random=2",
    link: "https://www.behance.net/search/projects?search=3d+animation"
  },
  {
    id: 3,
    title: "ECHOES OF REALITY",
    category: "EDITING",
    description: "A cinematic travel montage demonstrating rhythm, pacing, and sound design expertise.",
    details: "Shot across three continents, this edit focuses on match-cutting and sound bridging. The soundscape combines foley recordings with synthesized glitches to create a surreal transition between locations, emphasizing the memory-like quality of the footage.",
    imageUrl: "https://picsum.photos/800/600?random=3",
    link: "https://vimeo.com/categories/arts/experimental"
  },
  {
    id: 4,
    title: "GLITCH PROTOCOL",
    category: "MOTION GRAPHICS",
    description: "Typography-led motion piece exploring the concept of digital decay.",
    details: "Created entirely in Cinema 4D and After Effects using X-Particles. The typography deconstruction is driven by audio-reactive modifiers, ensuring every visual glitch is perfectly synced to the aggressive breakbeat soundtrack.",
    imageUrl: "https://picsum.photos/800/600?random=4",
    link: "https://www.pinterest.com/search/pins/?q=glitch%20art"
  }
];